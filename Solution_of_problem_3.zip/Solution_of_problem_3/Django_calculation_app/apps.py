from django.apps import AppConfig


class DjangoCalculationAppConfig(AppConfig):
    name = 'Django_calculation_app'
